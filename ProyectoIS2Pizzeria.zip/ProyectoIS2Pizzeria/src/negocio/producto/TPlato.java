package negocio.producto;

public class TPlato {

}
