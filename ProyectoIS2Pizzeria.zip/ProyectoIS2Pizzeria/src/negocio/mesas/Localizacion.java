package negocio.mesas;

public enum Localizacion {
	INTERIOR, EXTERIOR;
}
