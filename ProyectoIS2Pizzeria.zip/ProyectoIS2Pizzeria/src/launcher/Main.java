package launcher;

import presentacion.mesas.VistaAñadirMesa;

public class Main {
	
	public static void main(String[] args) {
		new VistaAñadirMesa(null);
	}
}
