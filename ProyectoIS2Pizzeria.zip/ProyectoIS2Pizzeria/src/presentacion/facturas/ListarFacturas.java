package presentacion.facturas;

import javax.swing.JFrame;

public class ListarFacturas extends JFrame{

}
