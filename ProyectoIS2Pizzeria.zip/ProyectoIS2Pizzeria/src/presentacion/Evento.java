package presentacion;

public enum Evento {
	ALTA_MESA, BAJA_MESA, LISTAR_MESAS, BUSCAR_MESA, MODIFICAR_MESA;
}
