package presentacion.factoria;

import presentacion.Evento;
import presentacion.IGUI;

public class FactoriaPresentacion extends FactoriaAbstractaPresentacion{
	
	FactoriaPresentacion(){
		
	}
	
	
	@Override
	IGUI createVista(Evento e) {
		// TODO Auto-generated method stub
		return null;
	}

}
