package presentacion;

public interface IGUI {
	public void actualizar(Evento e, Object datos);
}
