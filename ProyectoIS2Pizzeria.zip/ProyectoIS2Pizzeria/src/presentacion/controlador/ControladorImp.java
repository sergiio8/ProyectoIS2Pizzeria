package presentacion.controlador;

import presentacion.Evento;

public class ControladorImp extends Controlador {

	@Override
	public void accion(Evento e, Object datos) {
		// TODO Auto-generated method stub

	}

}
