package integracion.mesas;

import negocio.mesas.TMesas;

public class DAOMesasImp implements DAOMesas {

	@Override
	public Integer insertaMesa(TMesas tm) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Boolean daDeBajaMesa(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public TMesas obtenMesa(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Boolean modificaMesa(TMesas tm) {
		// TODO Auto-generated method stub
		return null;
	}

}
